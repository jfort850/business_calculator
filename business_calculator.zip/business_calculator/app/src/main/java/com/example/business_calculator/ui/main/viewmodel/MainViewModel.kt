          package com.example.business_calculator.ui.main.viewmodel

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}