package com.example.business_calculator

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

  private var canAddOperation = false

  override fun onCreate(savedInstanceState: Bundle?)
  {
      super.onCreate(savedInstanceState)
      setContentView(R.layout.main_activity)
  }

    fun numberAction(view: View){

    }
    fun operationAction(view: View)
    {

    }
    fun allClearAction(view: View){
      
    }
}